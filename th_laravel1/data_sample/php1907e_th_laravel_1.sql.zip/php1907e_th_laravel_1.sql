-- phpMyAdmin SQL Dump
-- version 4.4.15.7
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2019 at 12:24 PM
-- Server version: 5.6.37
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `php1907e_th_laravel_1`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint(20) unsigned NOT NULL,
  `category_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `publish` int(11) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `image_category`, `publish`, `ordering`, `description`, `created_at`, `updated_at`) VALUES
(1, 'category 1', 'upload/categories/87607Screen Shot 2019-10-07 at 5.09.40 PM.png', 1, 2, 'des 1', '2019-11-15 06:14:57', '2019-11-15 06:52:51');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(11) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `email` varchar(200) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `phone` varchar(200) NOT NULL,
  `updated_at` date NOT NULL,
  `node` text,
  `created_at` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `first_name`, `last_name`, `gender`, `email`, `address`, `phone`, `updated_at`, `node`, `created_at`) VALUES
(1, 'nguyen', 'van', 'nam', NULL, 'A105, M3M4 Building, 91 Nguyen Chi Thanh', '0936006058', '2019-11-27', NULL, '2019-11-27'),
(2, 'nguyen', 'van', 'nam', NULL, 'A105, M3M4 Building, 91 Nguyen Chi Thanh', '0936006058', '2019-11-27', NULL, '2019-11-27'),
(3, 'nguyen', 'van', 'nam', NULL, 'A105, M3M4 Building, 91 Nguyen Chi Thanh', '0936006058', '2019-11-27', NULL, '2019-11-27'),
(4, 'nguyen', 'van', 'nam', NULL, 'A105, M3M4 Building, 91 Nguyen Chi Thanh', '0936006058', '2019-11-27', NULL, '2019-11-27'),
(5, 'nguyen', 'van', 'nam', NULL, 'A105, M3M4 Building, 91 Nguyen Chi Thanh', '0936006058', '2019-11-27', NULL, '2019-11-27'),
(6, 'nguyen', 'van', 'nam', NULL, 'A105, M3M4 Building, 91 Nguyen Chi Thanh', '0936006058', '2019-11-27', NULL, '2019-11-27'),
(7, 'nguyen', 'van', 'nam', NULL, 'A105, M3M4 Building, 91 Nguyen Chi Thanh', '0936006058', '2019-11-27', NULL, '2019-11-27'),
(8, 'nguyen', 'van', 'nam', NULL, 'A105, M3M4 Building, 91 Nguyen Chi Thanh', '0936006058', '2019-11-27', NULL, '2019-11-27'),
(9, 'nguyen', 'van', 'nam', NULL, 'A105, M3M4 Building, 91 Nguyen Chi Thanh', '0936006058', '2019-11-27', NULL, '2019-11-27'),
(10, 'nguyen', 'van', 'nam', NULL, 'A105, M3M4 Building, 91 Nguyen Chi Thanh', '0936006058', '2019-11-27', NULL, '2019-11-27'),
(11, 'nguyen', 'van', 'nam', NULL, 'A105, M3M4 Building, 91 Nguyen Chi Thanh', '0936006058', '2019-11-27', NULL, '2019-11-27'),
(12, 'nguyen', 'van', 'nam', NULL, 'A105, M3M4 Building, 91 Nguyen Chi Thanh', '0936006058', '2019-11-27', NULL, '2019-11-27'),
(13, 'nguyen', '23232', 'nu', NULL, 'A105, M3M4 Building, 91 Nguyen Chi Thanh', '0936006058', '2019-11-27', NULL, '2019-11-27'),
(14, 'nguyen', 'sdsfds', 'nu', NULL, 'A105, M3M4 Building, 91 Nguyen Chi Thanh', '0936006058', '2019-11-27', NULL, '2019-11-27');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_10_25_135000_products', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Orders`
--

CREATE TABLE IF NOT EXISTS `Orders` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Orders`
--

INSERT INTO `Orders` (`id`, `customer_id`, `total`, `status`, `updated_at`, `created_at`) VALUES
(1, 4, 111, 'pending', '2019-11-27 00:00:00', '2019-11-27 00:00:00'),
(2, 5, 111, 'pending', '2019-11-27 12:08:13', '2019-11-27 12:08:13'),
(3, 6, 111, 'pending', '2019-11-27 12:13:16', '2019-11-27 12:13:16'),
(4, 7, 111, 'pending', '2019-11-27 12:13:35', '2019-11-27 12:13:35'),
(5, 8, 111, 'pending', '2019-11-27 12:13:58', '2019-11-27 12:13:58'),
(6, 9, 111, 'pending', '2019-11-27 12:14:38', '2019-11-27 12:14:38'),
(7, 10, 111, 'pending', '2019-11-27 12:14:51', '2019-11-27 12:14:51'),
(8, 11, 111, 'pending', '2019-11-27 12:15:59', '2019-11-27 12:15:59'),
(9, 12, 0, 'pending', '2019-11-27 12:16:55', '2019-11-27 12:16:55'),
(10, 13, 278, 'pending', '2019-11-27 12:17:25', '2019-11-27 12:17:25'),
(11, 14, 195, 'pending', '2019-11-27 12:20:41', '2019-11-27 12:20:41');

-- --------------------------------------------------------

--
-- Table structure for table `order_product`
--

CREATE TABLE IF NOT EXISTS `order_product` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_qty` int(11) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `product_price` float NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_product`
--

INSERT INTO `order_product` (`id`, `order_id`, `product_id`, `product_qty`, `product_name`, `product_price`) VALUES
(1, 5, 2, 4, 'product 4', 23),
(2, 6, 2, 4, 'product 4', 23),
(3, 7, 2, 4, 'product 4', 23),
(4, 8, 2, 4, 'product 4', 23),
(5, 10, 2, 10, 'product 4', 23),
(6, 11, 2, 7, 'product 4', 23);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` bigint(20) unsigned NOT NULL,
  `product_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_image_intro` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `publish` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  `price` double(8,2) DEFAULT NULL,
  `sale_price` double(8,2) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `full_description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `product_image_intro`, `publish`, `category_id`, `ordering`, `price`, `sale_price`, `description`, `full_description`, `created_at`, `updated_at`) VALUES
(1, 'product 3', 'upload/products/43959Screen Shot 2019-10-14 at 11.07.39 PM.png', 1, 1, 1, 560000.00, 500000.00, 'des1', 'full des1', '2019-11-13 06:02:05', '2019-11-13 06:02:05'),
(2, 'product 4', 'upload/products/43959Screen Shot 2019-10-14 at 11.07.39 PM.png', 1, 1, 6, 23.00, 540000.00, 'des 4', 'des 4', '2019-11-13 06:03:46', '2019-11-13 06:03:46'),
(3, 'product 5', 'upload/products/43959Screen Shot 2019-10-14 at 11.07.39 PM.png', 1, 1, 1, 300000.00, NULL, 'des 5', 'full des 5', '2019-11-13 06:13:01', '2019-11-13 06:13:01'),
(4, 'product 6', 'upload/products/43959Screen Shot 2019-10-14 at 11.07.39 PM.png', 1, 1, 1, 560000.00, 540000.00, 'des 6', 'full des 6', '2019-11-13 06:15:25', '2019-11-13 06:15:25'),
(11, 'ssdfsdfsd', 'upload/products/20335Screen Shot 2019-10-14 at 11.07.19 PM.png', 1, 1, 4, 232.00, NULL, 'sdfsdf', 'sdfsd', '2019-11-13 06:29:50', '2019-11-13 06:29:50'),
(12, NULL, 'upload/products/40979Screen Shot 2019-10-08 at 1.23.31 PM.png', 1, 1, NULL, NULL, NULL, NULL, NULL, '2019-11-13 06:30:13', '2019-11-13 06:30:13'),
(13, 'dasdas13', 'upload/products/43959Screen Shot 2019-10-14 at 11.07.39 PM.png', 1, 1, 23, 200.00, 232.00, 'sdfsd', 'sdfs', '2019-11-15 05:14:22', '2019-11-15 05:14:22'),
(14, 'san pham 144444566', 'upload/products/29445Screen Shot 2019-10-08 at 1.25.05 PM.png', 0, 1, 2, 200000.00, 170000.00, 'des sp 14', 'des sp 14', '2019-11-15 05:15:27', '2019-11-15 05:15:27');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `block` int(11) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Orders`
--
ALTER TABLE `Orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_product`
--
ALTER TABLE `order_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Orders`
--
ALTER TABLE `Orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `order_product`
--
ALTER TABLE `order_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
