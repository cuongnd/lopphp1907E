<?php
/**
 * @copyright	Copyright (c) 2019 dienvien. All rights reserved.
 * @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// no direct access
defined('_JEXEC') or die;

jimport('joomla.plugin.plugin');

/**
 * dienvien - user Plugin
 *
 * @package		Joomla.Plugin
 * @subpakage	dienvien.user
 */
class plgdienvienuser extends JPlugin {

	/**
	 * Constructor.
	 *
	 * @param 	$subject
	 * @param	array $config
	 */
	function __construct(&$subject, $config = array()) {
		// call parent constructor
		parent::__construct($subject, $config);
	}
	
}