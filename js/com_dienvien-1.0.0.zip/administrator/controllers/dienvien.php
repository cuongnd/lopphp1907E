<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Dienvien
 * @author     cuong <nguyendinhcuong@gmail.com>
 * @copyright  2019 cuong
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * Dienvien controller class.
 *
 * @since  1.6
 */
class DienvienControllerDienvien extends \Joomla\CMS\MVC\Controller\FormController
{
	/**
	 * Constructor
	 *
	 * @throws Exception
	 */
	public function __construct()
	{
		$this->view_list = 'dienviens';
		parent::__construct();
	}
}
